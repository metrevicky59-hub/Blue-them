# Blue Them — Men's Clothing Website

Open `index.html` in a browser to preview the website.

Included:
- Blue Them branding
- Men's-only collection
- Product cards
- Add-to-cart
- Checkout form
- Cash on Delivery selection
- Online-payment placeholder

Important: online payments are only a UI placeholder. Before taking real payments, connect a payment gateway such as Razorpay/Stripe and add a real backend/order system.

To customize products, edit the `products` list near the bottom of `index.html`.
